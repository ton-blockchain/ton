<!-- Describe the issue -->
<!--- What behavior did you expect? -->

<!--- What was the actual behavior? -->

<!--- How reliably can you reproduce the issue, what are the steps to do so? -->

<!-- What version of TON are you using, where did you get it (github actions, self-compiled, etc)? -->

<!-- What type of machine are you observing the error on (OS/CPU and disk type)? -->

<!-- Any extra information that might be useful in the debugging process. -->
<!--- This is normally the contents of a `debug.log` or `config.log` file. Raw text or a link to a pastebin type site are preferred. -->
